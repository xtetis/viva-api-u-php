<div id="container_show_message">
</div>