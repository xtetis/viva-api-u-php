<script src="/assets/components/datta-able-theme/assets/js/plugins/popper.min.js"></script>
<script src="/assets/components/datta-able-theme/assets/js/plugins/simplebar.min.js"></script>
<script src="/assets/components/datta-able-theme/assets/js/plugins/bootstrap.min.js"></script>
<script src="/assets/components/datta-able-theme/assets/js/fonts/custom-font.js"></script>
<script src="/assets/components/datta-able-theme/assets/js/pcoded.js"></script>
<script src="/assets/components/datta-able-theme/assets/js/plugins/feather.min.js"></script>


<script src="/assets/js/jquery-3.7.1.min.js"></script>
<script src="/assets/js/test_api.js?v=<?php echo e(time()); ?>"></script>






</body>
<!-- [Body] end -->

</html>
<?php /**PATH /var/www/html/engine/resources/views/blocks/endbody.blade.php ENDPATH**/ ?>